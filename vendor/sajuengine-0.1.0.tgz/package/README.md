# sajuengine

출생 정보를 사주 계산과 구조화된 판단으로 바꾸는 TypeScript/Node 패키지다. 기존 계산·판단 코드를 재사용한다. LLM, 프롬프트, 생성 문장 검사, 화면, 인증, 저장소는 포함하지 않는다.

```text
출생 입력 → 계산 → 원국 판단 → 기간 변화 → 질문별 판단
                                             ↓
                         결론 · 근거 · 반대 근거 · 한계
```

## 빌드와 설치

Node 24, npm 11.19.1 이상 11.x를 사용한다. 저장소 루트에서:

```sh
npm ci --ignore-scripts
npm run pack:engine
```

다른 서비스 저장소에서 만들어진 파일을 설치한다:

```sh
npm install /path/to/sajuengine-0.1.0.tgz --ignore-scripts
```

`private: true`는 공개 npm 업로드를 막는다. 파일 설치에는 영향을 주지 않는다. 배포 파일에는 실행 가능한 ESM JavaScript, 타입 선언, 선택형 고전 JSON이 들어간다. TypeScript 실행기나 이 저장소의 경로 별칭이 필요하지 않다.

## 입구별 역할

| import                 | 용도                                                                  |
| ---------------------- | --------------------------------------------------------------------- |
| `sajuengine`           | 입력 계약, 계산·판단, 기능 구성, 질문별 판단, 요청 안에서 계산 재사용 |
| `sajuengine/node`      | 기본 의존성 조립과 만세력·시간대·해시 어댑터                          |
| `sajuengine/materials` | 고전 조회·자료 상태·처방과 정책 대조. 대용량 JSON 자동 로드 없음      |
| `sajuengine/catalog`   | 이 저장소의 고전 데이터 로더                                          |
| `sajuengine/testing`   | 서비스의 기능 정의를 검사하는 합성 입력·도우미                        |

## 첫 계산

```js
import { PublicBirthInputSchema, toAnalysisInput, calculateHashedCoreExport } from "sajuengine";
import { createDefaultDependencies } from "sajuengine/node";

const birth = PublicBirthInputSchema.parse({
  birthDate: "1998-09-19",
  birthTime: { status: "known", time: "16:00" },
  gender: "male",
  calendar: { type: "solar" },
  birthPlace: { timezoneId: "Asia/Seoul", longitudeDeg: 126.978 },
  timeCorrection: "standard",
});
const deps = createDefaultDependencies();
const result = calculateHashedCoreExport(toAnalysisInput(birth), deps, deps.hash);
console.log(result.document.status);
```

서비스는 자기 기능을 `defineFeatureSet`으로 구성하고 `executeDefinedFeature`로 실행한다. 여러 기능을 실행할 때는 `createFeatureSession`을 한 요청 안에서 사용해 원국 계산을 재사용한다. 기간·상대 판단은 별도로 계산한다. 사용 뒤 `dispose()`로 버린다.

`answerInquiry` 또는 `createInquiryReader`는 계산된 결과를 받아 질문의 주제·대상·기간에 맞는 근거를 고른다. 같은 원국의 결과만 함께 받으며, 기간이 다른 근거를 섞지 않는다. 추가 판단은 명시적인 `InquiryRule`로 연결한다. 예제는 저장소의 `examples/inquiries.ts`를 참고한다.

## 범위와 자료 상태

- 기존 M01~M08은 채택된 관법의 규칙이다. 명리학 전체의 유일한 정답이나 실제 사건의 확률을 뜻하지 않는다.
- 원국·시간 변화·두 원국 관계의 계산을 제공한다. 일반 길흉을 자동으로 연애·재물·건강 점수로 바꾸지 않는다.
- 지원되지 않는 질문은 `unsupported` 등 명시적 상태로 반환한다. 건강 진단이나 특정 사건 발생일을 확정하는 내장 규칙은 없다.
- 시각 미상은 관측한 기둥과 전체 원국의 결핍을 구별한다. 절기가 시진 안에 있으면 대표 시각 계산의 한계를 표시한다.
- 원문 192개, 요약 259개, 궁통보감 처방 120개를 보존한다. 요약은 AI 작성·자동검사 통과 상태이며 전문가 감수 완료가 아니다. 처방은 119개 자동검사 통과, 1개 실패다.
- 고전 처방의 첫 천간과 채택 용신·희신의 일치 여부는 참고 비교다. 전체 조건 검증이나 유일한 용신 결정법으로 사용하지 않는다.

LLM을 쓸지, 어떤 자료를 인용할지, 글을 어떻게 검사할지는 설치하는 서비스가 정한다. 엔진 자체에는 API 키나 `.env`가 필요하지 않다.
