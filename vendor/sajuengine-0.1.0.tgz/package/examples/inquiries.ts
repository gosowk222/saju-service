/**
 * A service can turn this structured material into cards, a calendar or an LLM report.
 * Runtime inputs/keys for an LLM are deliberately not part of the engine example.
 */
import {
  defineFeatureSet,
  executeDefinedFeatures,
  createInquiryReader,
  toAnalysisInput,
  type PublicBirthInput,
} from "sajuengine";
import { createDefaultDependencies } from "sajuengine/node";

const definitions = defineFeatureSet([
  {
    id: "natal",
    version: "1.0.0",
    modules: ["M01", "M02", "M03", "M04"],
    topics: ["romance", "wealth", "career"],
    targetKind: "none",
  },
  {
    id: "calendar-year",
    version: "1.0.0",
    modules: ["M01", "M02", "M05", "M06", "M07"],
    optional: ["M05"],
    targetKind: "year-months",
  },
]);

export function buildCalendarMaterials(birth: PublicBirthInput, year: number) {
  const input = toAnalysisInput(birth);
  // The natal chart is calculated once for this batch and reused by both features.
  const results = executeDefinedFeatures(
    definitions,
    [
      { featureId: "natal", ...input },
      {
        featureId: "calendar-year",
        ...input,
        target: { kind: "year-months", year, timezoneId: birth.birthPlace.timezoneId },
      },
    ],
    createDefaultDependencies(),
  );
  const reader = createInquiryReader(results);
  const periodIds = reader.periods
    .filter((period) => period.kind === "monthly")
    .map((period) => period.id);
  return {
    // A missing conclusion for a month means no matching rule, not "no opportunity this month".
    romance: reader.answer({ domain: "romance", kind: "timing", periodIds }),
    wealth: reader.answer({ domain: "wealth", kind: "timing", periodIds }),
    career: reader.answer({ domain: "career", kind: "timing", periodIds }),
    natalWealth: reader.answer({ domain: "wealth", kind: "natal" }),
    // Health needs a separately reviewed rule; the default explicitly reports unsupported.
    health: reader.answer({ domain: "health", kind: "natal" }),
  };
}
